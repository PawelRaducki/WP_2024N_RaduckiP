public class MazeDirector {

    private MazeBuilder builder;

    public MazeDirector(MazeBuilder builder) {
        this.builder = builder;
    }

    public void constructBasicMaze() {
        builder.createRoom(1);
        builder.createRoom(2);
        builder.createDoor(1, 2);
    }

    public Maze retrieveMaze() {
        return builder.constructMaze();
    }
}
