public interface MazeBuilder {

    void createRoom(int roomNumber);

    void createDoor(int roomFrom, int roomTo);

    Maze constructMaze();
}
