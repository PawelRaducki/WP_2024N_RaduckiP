import java.awt.Image;

public class Room extends MapSite {

    private int nr;
    private MapSite[] sites;

    public Room(int x, int y, int nr) {
        super(x, y);
        this.nr = nr;
        this.sites = new MapSite[4];
    }

    public void setSite(Directions direction, MapSite mapSite) {
        int index = direction.ordinal();
        if (mapSite instanceof Wall) {
            if (direction == Directions.East) {
                mapSite.setX(getX() + LENGTH);
            } else if (direction == Directions.South) {
                mapSite.setY(getY() + LENGTH);
            } else {
                mapSite.setX(getX());
                mapSite.setY(getY());
            }
        }
        sites[index] = mapSite;
    }

    @Override
    public void draw(Image image) {
        for (MapSite site : sites) {
            if (site != null) {
                site.draw(image);
            }
        }
    }
}
