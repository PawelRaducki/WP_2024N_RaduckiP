import java.awt.Image;
import java.util.ArrayList;
import java.util.List;

public class Maze {

    private List<Room> rooms;

    public Maze() {
        this.rooms = new ArrayList<>();
    }

    public void addRoom(Room room) {
        rooms.add(room);
    }

    public void draw(Image image) {
        rooms.forEach(room -> room.draw(image));
    }
}
