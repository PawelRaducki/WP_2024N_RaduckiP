import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

public class Wall extends MapSite {

    private Directions direction;

    public Wall(int x, int y, Directions direction) {
        super(x, y);
        this.direction = direction;
    }

    @Override
    public void draw(Image image) {
        Graphics g = image.getGraphics();
        int x = getX();
        int y = getY();
        g.setColor(Color.BLACK);
        if (direction == Directions.North || direction == Directions.South) {
            g.drawLine(x, y, x + MapSite.LENGTH, y);
        } else {
            g.drawLine(x, y, x, y + MapSite.LENGTH);
        }
    }
}
