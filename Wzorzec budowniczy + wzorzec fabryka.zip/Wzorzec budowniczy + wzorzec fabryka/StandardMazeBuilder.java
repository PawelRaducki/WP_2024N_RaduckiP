import java.util.HashMap;
import java.util.Map;

public class StandardMazeBuilder implements MazeBuilder {

    private Maze maze;
    private Map<Integer, Room> roomMap;

    public StandardMazeBuilder() {
        maze = new Maze();
        roomMap = new HashMap<>();
    }

    @Override
    public void createRoom(int roomNumber) {
        if (!roomMap.containsKey(roomNumber)) {
            Room room = new Room(50 * roomNumber, 100, roomNumber);
            roomMap.put(roomNumber, room);
            maze.addRoom(room);
        }
    }

    @Override
    public void createDoor(int roomFrom, int roomTo) {
        Room r1 = roomMap.get(roomFrom);
        Room r2 = roomMap.get(roomTo);

        if (r1 != null && r2 != null) {
            Door door = new Door(r1, r2);
            r1.setSite(Directions.East, door);
            r2.setSite(Directions.West, door);
        }
    }

    @Override
    public Maze constructMaze() {
        return maze;
    }
}
