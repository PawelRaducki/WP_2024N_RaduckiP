import java.util.Scanner;

interface OperationStrategy {
    double doOperation(double a, double b);
}

class AddOperation implements OperationStrategy {
    @Override
    public double doOperation(double a, double b) {
        return a + b;
    }
}

class SubtractOperation implements OperationStrategy {
    @Override
    public double doOperation(double a, double b) {
        return a - b;
    }
}

class MultiplyOperation implements OperationStrategy {
    @Override
    public double doOperation(double a, double b) {
        return a * b;
    }
}

class DivideOperation implements OperationStrategy {
    @Override
    public double doOperation(double a, double b) {
        if (b == 0) {
            throw new ArithmeticException("Nie można dzielić przez zero!");
        }
        return a / b;
    }
}

class Calculator {
    private OperationStrategy operationStrategy;

    public void setOperationStrategy(OperationStrategy operationStrategy) {
        this.operationStrategy = operationStrategy;
    }

    public double calculate(double a, double b) {
        if (operationStrategy == null) {
            throw new IllegalStateException("Strategia nie została ustawiona!");
        }
        return operationStrategy.doOperation(a, b);
    }
}

class OperationFactory {
    public static OperationStrategy getOperation(char operator) {
        switch (operator) {
            case '+': return new AddOperation();
            case '-': return new SubtractOperation();
            case '*': return new MultiplyOperation();
            case '/': return new DivideOperation();
            default: throw new IllegalArgumentException("Nieprawidłowy operator!");
        }
    }
}

public class CalculatorApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Calculator calculator = new Calculator();

        System.out.println("Prosty kalkulator (Strategia). Dostępne operacje: +, -, *, /");
        
        System.out.print("Podaj pierwszą liczbę: ");
        double a = scanner.nextDouble();

        System.out.print("Podaj operator (+, -, *, /): ");
        char operator = scanner.next().charAt(0);

        System.out.print("Podaj drugą liczbę: ");
        double b = scanner.nextDouble();

        try {
            calculator.setOperationStrategy(OperationFactory.getOperation(operator));
            
            double result = calculator.calculate(a, b);
            System.out.println("Wynik: " + result);

        } catch (IllegalArgumentException | ArithmeticException e) {
            System.out.println("Błąd: " + e.getMessage());
        }
    }
}
