import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

public class Wall extends MapSite {
    private Directions direction;

    public Wall(int x, int y, Directions direction) {
        super(x, y);
        this.direction = direction;
    }

    @Override
    public void draw(Image image) {
        Graphics g = image.getGraphics();
        g.setColor(Color.BLACK);
        drawWall(g);
    }

    private void drawWall(Graphics g) {
        int sx = getX();
        int sy = getY();
        int length = MapSite.LENGHT;

        switch (direction) {
            case North:
            case South:
                drawHorizontalWall(g, sx, sy, length);
                break;

            case East:
            case West:
                drawVerticalWall(g, sx, sy, length);
                break;
        }
    }

    private void drawHorizontalWall(Graphics g, int sx, int sy, int length) {
        g.drawLine(sx, sy, sx + length, sy);
    }

    private void drawVerticalWall(Graphics g, int sx, int sy, int length) {
        g.drawLine(sx, sy, sx, sy + length);
    }
}
