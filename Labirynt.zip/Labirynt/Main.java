import java.awt.*;
import javax.swing.*;

public class Main extends JFrame {
    private Maze maze;

    public Main() {
        super("Maze");
        configureWindow();
        maze = new Maze();
    }

    private void configureWindow() {
        setSize(300, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);

        Image offImage = createOffscreenImage();
        if (offImage != null) {
            drawMaze(offImage, g);
        }
    }

    private Image createOffscreenImage() {
        return createImage(getWidth(), getHeight());
    }

    private void drawMaze(Image offImage, Graphics g) {
        maze.draw(offImage);
        g.drawImage(offImage, 0, 0, this);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Main app = new Main();
            app.setVisible(true);
        });
    }
}
