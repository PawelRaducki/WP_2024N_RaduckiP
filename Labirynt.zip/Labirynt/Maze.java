import java.awt.Image;
import java.util.ArrayList;
import java.util.List;

public class Maze {
    private List<Room> rooms = new ArrayList<>();

    public Maze() {
        int offsetX = 50;
        int offsetY = 75;

        createRooms(offsetX, offsetY);

        createDoors();
    }

    private void createRooms(int offsetX, int offsetY) {
        Room r1 = new Room(1, offsetX + 0, offsetY + 50);
        Room r2 = new Room(2, offsetX + 50, offsetY + 50);
        Room r3 = new Room(3, offsetX + 50, offsetY + 0);
        Room r4 = new Room(4, offsetX + 50, offsetY + 100);
        Room r5 = new Room(5, offsetX + 100, offsetY + 50);
        Room r6 = new Room(6, offsetX + 150, offsetY + 0);
        Room r7 = new Room(7, offsetX + 150, offsetY + 50);
        Room r8 = new Room(8, offsetX + 150, offsetY + 100);

        rooms.add(r1);
        rooms.add(r2);
        rooms.add(r3);
        rooms.add(r4);
        rooms.add(r5);
        rooms.add(r6);
        rooms.add(r7);
        rooms.add(r8);
    }

    private void createDoors() {
        Door d12 = new Door(rooms.get(0), rooms.get(1), MapSite.Directions.East);
        rooms.get(0).setSite(MapSite.Directions.East, d12);
        rooms.get(1).setSite(MapSite.Directions.West, d12);

        createWallsForRoom(rooms.get(0));

        Door d23 = new Door(rooms.get(1), rooms.get(2), MapSite.Directions.North);
        rooms.get(1).setSite(MapSite.Directions.North, d23);
        rooms.get(2).setSite(MapSite.Directions.South, d23);

        Door d24 = new Door(rooms.get(1), rooms.get(3), MapSite.Directions.South);
        rooms.get(1).setSite(MapSite.Directions.South, d24);
        rooms.get(3).setSite(MapSite.Directions.North, d24);

        Door d25 = new Door(rooms.get(1), rooms.get(4), MapSite.Directions.East);
        rooms.get(1).setSite(MapSite.Directions.East, d25);
        rooms.get(4).setSite(MapSite.Directions.West, d25);

        createWallsForRoom(rooms.get(2));
        createWallsForRoom(rooms.get(3));
        createWallsForRoom(rooms.get(4));

        Door d67 = new Door(rooms.get(5), rooms.get(6), MapSite.Directions.South);
        rooms.get(5).setSite(MapSite.Directions.South, d67);
        rooms.get(6).setSite(MapSite.Directions.North, d67);

        createWallsForRoom(rooms.get(5));

        Door d78 = new Door(rooms.get(6), rooms.get(7), MapSite.Directions.South);
        rooms.get(6).setSite(MapSite.Directions.South, d78);
        rooms.get(7).setSite(MapSite.Directions.North, d78);

        createWallsForRoom(rooms.get(6));
        createWallsForRoom(rooms.get(7));
    }

    private void createWallsForRoom(Room room) {
        room.setSite(MapSite.Directions.North, new Wall(room.getX(), room.getY(), MapSite.Directions.North));
        room.setSite(MapSite.Directions.East, new Wall(room.getX(), room.getY(), MapSite.Directions.East));
        room.setSite(MapSite.Directions.West, new Wall(room.getX(), room.getY(), MapSite.Directions.West));
        room.setSite(MapSite.Directions.South, new Wall(room.getX(), room.getY(), MapSite.Directions.South));
    }


    public void draw(Image image) {
        for (Room r : rooms) {
            r.draw(image);
        }
    }
}
