import java.awt.Graphics;
import java.awt.Image;

public class Room extends MapSite {
    private MapSite[] sites = new MapSite[4];
    private int roomNumber;

    public Room(int roomNumber, int x, int y) {
        super(x, y);
        this.roomNumber = roomNumber;
    }

    public void setSite(Directions direction, MapSite site) {
        sites[direction.ordinal()] = site;
        updateSiteCoordinates(direction, site);
    }

    public MapSite getSite(Directions direction) {
        return sites[direction.ordinal()];
    }

    @Override
    public void draw(Image image) {
        drawSites(image);
        drawRoomNumber(image);
    }

    private void drawSites(Image image) {
        for (MapSite m : sites) {
            if (m != null) {
                m.draw(image);
            }
        }
    }

    private void drawRoomNumber(Image image) {
        Graphics g = image.getGraphics();
        g.drawString(String.valueOf(roomNumber), getX() + 5, getY() + 25);
    }

    private void updateSiteCoordinates(Directions direction, MapSite site) {
        if (site instanceof Wall || site instanceof Door) {
            switch (direction) {
                case North:
                    site.setX(getX());
                    site.setY(getY());
                    break;
                case East:
                    site.setX(getX() + LENGHT);
                    site.setY(getY());
                    break;
                case South:
                    site.setX(getX());
                    site.setY(getY() + LENGHT);
                    break;
                case West:
                    site.setX(getX());
                    site.setY(getY());
                    break;
            }
        }
    }
}
