package calculator.model;

import calculator.model.operation.OperationStrategy;

public class CalculatorModel {
    private double firstOperand;
    private double secondOperand;
    private double result;
    private OperationStrategy operationStrategy;

    public CalculatorModel() {
    }

    public void setFirstOperand(double firstOperand) {
        this.firstOperand = firstOperand;
    }

    public void setSecondOperand(double secondOperand) {
        this.secondOperand = secondOperand;
    }

    public double getResult() {
        return result;
    }

    public void setOperationStrategy(OperationStrategy operationStrategy) {
        this.operationStrategy = operationStrategy;
    }

    public void calculateResult() {
        validateOperationStrategy();
        result = operationStrategy.doOperation(firstOperand, secondOperand);
    }

    private void validateOperationStrategy() {
        if (operationStrategy == null) {
            throw new IllegalStateException("Strategia (operacja) nie została ustawiona!");
        }
    }
}
