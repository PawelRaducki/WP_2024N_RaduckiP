package calculator.model.operation;

public class AddOperation implements OperationStrategy {

    @Override
    public double execute(double firstOperand, double secondOperand) {
        return add(firstOperand, secondOperand);
    }

    private double add(double firstOperand, double secondOperand) {
        return firstOperand + secondOperand;
    }
}
