package calculator.model.operation;

public class MultiplyOperation implements OperationStrategy {

    @Override
    public double execute(double firstOperand, double secondOperand) {
        return multiply(firstOperand, secondOperand);
    }

    private double multiply(double firstOperand, double secondOperand) {
        return firstOperand * secondOperand;
    }
}
