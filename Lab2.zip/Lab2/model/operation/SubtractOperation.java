package calculator.model.operation;

public class SubtractOperation implements OperationStrategy {

    @Override
    public double execute(double firstOperand, double secondOperand) {
        return subtract(firstOperand, secondOperand);
    }

    private double subtract(double firstOperand, double secondOperand) {
        return firstOperand - secondOperand;
    }
}
