package calculator.model.operation;

public interface OperationStrategy {
    double execute(double firstOperand, double secondOperand);
}
