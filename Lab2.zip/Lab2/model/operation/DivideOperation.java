package calculator.model.operation;

public class DivideOperation implements OperationStrategy {

    @Override
    public double execute(double firstOperand, double secondOperand) {
        validateDivision(secondOperand);
        return divide(firstOperand, secondOperand);
    }

    private void validateDivision(double secondOperand) {
        if (secondOperand == 0) {
            throw new ArithmeticException("Nie można dzielić przez zero!");
        }
    }

    private double divide(double firstOperand, double secondOperand) {
        return firstOperand / secondOperand;
    }
}
