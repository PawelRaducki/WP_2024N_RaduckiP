package calculator.controller;

import calculator.model.CalculatorModel;
import calculator.model.operation.*;
import calculator.view.CalculatorView;

public class CalculatorController {
    private final CalculatorModel model;
    private final CalculatorView view;

    public CalculatorController(CalculatorModel model, CalculatorView view) {
        this.model = model;
        this.view = view;
    }

    public void start() {
        view.displayWelcomeMessage();
        
        double firstOperand = view.askForNumber("Podaj pierwszą liczbę: ");
        char operator = view.askForOperator("Podaj operator (+, -, *, /): ");
        double secondOperand = view.askForNumber("Podaj drugą liczbę: ");
        
        model.setFirstOperand(firstOperand);
        model.setSecondOperand(secondOperand);

        setOperationStrategy(operator);

        try {
            model.calculateResult();
            view.displayResult(model.getResult());
        } catch (ArithmeticException | IllegalStateException e) {
            view.displayError(e.getMessage());
        }
    }

    private void setOperationStrategy(char operator) {
        switch (operator) {
            case '+':
                model.setOperationStrategy(new AddOperation());
                break;
            case '-':
                model.setOperationStrategy(new SubtractOperation());
                break;
            case '*':
                model.setOperationStrategy(new MultiplyOperation());
                break;
            case '/':
                model.setOperationStrategy(new DivideOperation());
                break;
            default:
                view.displayError("Nieprawidłowy operator!");
                throw new IllegalArgumentException("Nieprawidłowy operator!");
        }
    }
}
