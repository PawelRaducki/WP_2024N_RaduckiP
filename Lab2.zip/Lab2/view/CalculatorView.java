package calculator.view;

import java.util.Scanner;

public class CalculatorView {
    private final Scanner scanner;

    public CalculatorView() {
        this.scanner = new Scanner(System.in);
    }

    public void displayWelcomeMessage() {
        printMessage("Prosty kalkulator w architekturze MVC + wzorzec Strategia.");
        printMessage("Dostępne operatory: +, -, *, /");
    }

    public double askForNumber(String prompt) {
        return getUserInput(prompt);
    }

    public char askForOperator(String prompt) {
        System.out.print(prompt);
        return scanner.next().charAt(0);
    }

    public void displayResult(double result) {
        printMessage("Wynik: " + result);
    }

    public void displayError(String errorMessage) {
        printMessage("Błąd: " + errorMessage);
    }

    private void printMessage(String message) {
        System.out.println(message);
    }

    private double getUserInput(String message) {
        System.out.print(message);
        return scanner.nextDouble();
    }
}
