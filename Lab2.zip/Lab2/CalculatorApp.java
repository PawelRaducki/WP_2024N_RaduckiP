package calculator;

public class CalculatorApp {

    public static void main(String[] args) {
        new CalculatorApp().startCalculator();
    }

    private void startCalculator() {
        CalculatorModel model = createModel();
        CalculatorView view = createView();
        CalculatorController controller = createController(model, view);

        controller.run();
    }

    private CalculatorModel createModel() {
        return new CalculatorModel();
    }

    private CalculatorView createView() {
        return new CalculatorView();
    }

    private CalculatorController createController(CalculatorModel model, CalculatorView view) {
        return new CalculatorController(model, view);
    }
}
